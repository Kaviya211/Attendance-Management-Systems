# School Student Attendance Management System

A starter full-stack school attendance project:
- Backend: Java 17, Spring Boot, Spring Data JPA, REST API
- Frontend: React + Vite + Lucide icons
- Database: MySQL 8

## Features
- Teacher registration and login (demo implementation)
- Student creation, listing, editing and deletion API
- Mark attendance: PRESENT, ABSENT, LATE, LEAVE
- Attendance history by date or student
- Edit attendance status/remarks
- Dashboard summary, responsive layout and light animations
- Teacher profile information and logout

## Requirements
1. JDK 17 or newer
2. Eclipse IDE with Maven support (Spring Tools optional)
3. MySQL Server 8+
4. Node.js 20+ and npm

## 1. Database
Open MySQL Workbench and run `database/school_attendance.sql`.
Edit `backend/src/main/resources/application.properties` and set your MySQL password.

## 2. Run backend in Eclipse
1. Extract this ZIP.
2. Open Eclipse.
3. Choose File > Import > Maven > Existing Maven Projects.
4. Browse to the extracted `SchoolAttendanceManagement/backend` folder.
5. Finish and wait for Maven dependencies to download.
6. Open `AttendanceApplication.java`.
7. Right-click > Run As > Java Application (or Spring Boot App).
8. Backend should start at http://localhost:8080.

## 3. Run React frontend
Open a terminal in the `frontend` folder and run:
```bash
npm install
npm run dev
```
Open the Vite URL printed in the terminal (usually http://localhost:5173).

## 4. First use
- Choose "New teacher? Create account".
- Register a teacher, then sign in.
- Add students in Students.
- Mark attendance and view Attendance history.

## API overview
| Method | Endpoint | Purpose |
|---|---|---|
| POST | /api/teachers/register | Register teacher |
| POST | /api/teachers/login | Login |
| GET | /api/teachers/{id} | Teacher profile |
| POST | /api/students | Add student |
| GET | /api/students | List students |
| GET | /api/students/{id} | Student profile |
| PUT | /api/students/{id} | Update student |
| DELETE | /api/students/{id} | Delete student |
| POST | /api/attendance | Mark/update attendance for student + date |
| GET | /api/attendance | All attendance |
| GET | /api/attendance?date=2026-11-11 | Attendance for date |
| GET | /api/attendance?studentId=1 | Student attendance history |
| PUT | /api/attendance/{id} | Edit attendance |

## Important security note
This is an educational starter, not a production-ready school system. The sample login stores passwords as plain text and does not implement authorization. Do not use real student/teacher personal data until you add BCrypt password hashing, Spring Security, JWT/session authentication, role-based authorization, request validation, backups, and privacy controls.

## Troubleshooting
- MySQL connection refused: start the MySQL80 service and confirm port 3306.
- Access denied: verify username/password in application.properties.
- Port 8080 in use: change `server.port` in application.properties.
- Frontend cannot connect: make sure backend is running on port 8080.
- Maven errors: confirm Eclipse is using JDK 17 and update the Maven project.
