package com.school.attendance.model;
import jakarta.persistence.*;
@Entity @Table(name="students")
public class Student {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String admissionNo;
 @Column(nullable=false) private String name;
 private String className;
 private String section;
 private String guardianName;
 private String guardianPhone;
 private String email;
 public Student() {}
 public Student(String admissionNo,String name,String className,String section,String guardianName,String guardianPhone,String email){
  this.admissionNo=admissionNo;this.name=name;this.className=className;this.section=section;this.guardianName=guardianName;this.guardianPhone=guardianPhone;this.email=email;
 }
 public Long getId(){return id;} public String getAdmissionNo(){return admissionNo;} public void setAdmissionNo(String v){admissionNo=v;}
 public String getName(){return name;} public void setName(String v){name=v;} public String getClassName(){return className;} public void setClassName(String v){className=v;}
 public String getSection(){return section;} public void setSection(String v){section=v;} public String getGuardianName(){return guardianName;} public void setGuardianName(String v){guardianName=v;}
 public String getGuardianPhone(){return guardianPhone;} public void setGuardianPhone(String v){guardianPhone=v;} public String getEmail(){return email;} public void setEmail(String v){email=v;}
}
