package com.school.attendance.controller;
import com.school.attendance.model.*;
import com.school.attendance.repository.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDate;
import java.util.*;

@RestController @RequestMapping("/api")
public class ApiController {
 private final TeacherRepository teachers; private final StudentRepository students; private final AttendanceRepository attendance;
 public ApiController(TeacherRepository t,StudentRepository s,AttendanceRepository a){teachers=t;students=s;attendance=a;}

 @PostMapping("/teachers/register") public Map<String,Object> register(@RequestBody Map<String,String> body){
  String email=required(body,"email");
  if(teachers.findByEmail(email).isPresent()) throw new ResponseStatusException(HttpStatus.CONFLICT,"Email already registered");
  Teacher t=teachers.save(new Teacher(required(body,"name"),email,required(body,"password"))); return Map.of("id",t.getId(),"name",t.getName(),"email",t.getEmail());
 }
 @PostMapping("/teachers/login") public Map<String,Object> login(@RequestBody Map<String,String> body){
  Teacher t=teachers.findByEmail(required(body,"email")).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid email or password"));
  if(!t.getPassword().equals(required(body,"password"))) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid email or password");
  return Map.of("id",t.getId(),"name",t.getName(),"email",t.getEmail());
 }
 @GetMapping("/teachers/{id}") public Map<String,Object> teacher(@PathVariable Long id){
  Teacher t=teachers.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
  return Map.of("id",t.getId(),"name",t.getName(),"email",t.getEmail());
 }
 @PostMapping("/students") public Student addStudent(@RequestBody Student s){
  if(students.findByAdmissionNo(s.getAdmissionNo()).isPresent()) throw new ResponseStatusException(HttpStatus.CONFLICT,"Admission number already exists");
  return students.save(s);
 }
 @GetMapping("/students") public List<Student> allStudents(){return students.findAll();}
 @GetMapping("/students/{id}") public Student getStudent(@PathVariable Long id){return students.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));}
 @PutMapping("/students/{id}") public Student updateStudent(@PathVariable Long id,@RequestBody Student input){
  Student s=getStudent(id); s.setAdmissionNo(input.getAdmissionNo());s.setName(input.getName());s.setClassName(input.getClassName());s.setSection(input.getSection());s.setGuardianName(input.getGuardianName());s.setGuardianPhone(input.getGuardianPhone());s.setEmail(input.getEmail());return students.save(s);
 }
 @DeleteMapping("/students/{id}") public ResponseEntity<Void> deleteStudent(@PathVariable Long id){students.delete(getStudent(id));return ResponseEntity.noContent().build();}
 @PostMapping("/attendance") public Attendance mark(@RequestBody Map<String,String> body){
  Long studentId=Long.valueOf(required(body,"studentId")); LocalDate date=LocalDate.parse(body.getOrDefault("attendanceDate",LocalDate.now().toString()));
  Student s=getStudent(studentId); String status=required(body,"status").toUpperCase();
  if(!List.of("PRESENT","ABSENT","LATE","LEAVE").contains(status)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Status must be PRESENT, ABSENT, LATE or LEAVE");
  Attendance a=attendance.findByStudentIdOrderByAttendanceDateDesc(studentId).stream().filter(x->x.getAttendanceDate().equals(date)).findFirst().orElse(new Attendance());
  a.setStudent(s);a.setAttendanceDate(date);a.setStatus(status);a.setRemarks(body.getOrDefault("remarks",""));return attendance.save(a);
 }
 @GetMapping("/attendance") public List<Attendance> history(@RequestParam(required=false) String date,@RequestParam(required=false) Long studentId){
  if(studentId!=null)return attendance.findByStudentIdOrderByAttendanceDateDesc(studentId);
  if(date!=null&&!date.isBlank())return attendance.findByAttendanceDate(LocalDate.parse(date));
  return attendance.findAll();
 }
 @PutMapping("/attendance/{id}") public Attendance editAttendance(@PathVariable Long id,@RequestBody Map<String,String> body){
  Attendance a=attendance.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
  if(body.containsKey("status"))a.setStatus(body.get("status").toUpperCase());
  if(body.containsKey("remarks"))a.setRemarks(body.get("remarks"));
  if(body.containsKey("attendanceDate"))a.setAttendanceDate(LocalDate.parse(body.get("attendanceDate")));
  return attendance.save(a);
 }
 private String required(Map<String,String> b,String key){String v=b.get(key);if(v==null||v.isBlank())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,key+" is required");return v.trim();}
}
