package com.school.attendance.repository;
import com.school.attendance.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface StudentRepository extends JpaRepository<Student,Long>{Optional<Student> findByAdmissionNo(String admissionNo);}
