package com.school.attendance.model;
import jakarta.persistence.*;
@Entity @Table(name="teachers")
public class Teacher {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String name;
 @Column(nullable=false, unique=true) private String email;
 @Column(nullable=false) private String password;
 public Teacher() {}
 public Teacher(String name,String email,String password){this.name=name;this.email=email;this.password=password;}
 public Long getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;}
 public String getEmail(){return email;} public void setEmail(String v){email=v;}
 public String getPassword(){return password;} public void setPassword(String v){password=v;}
}
