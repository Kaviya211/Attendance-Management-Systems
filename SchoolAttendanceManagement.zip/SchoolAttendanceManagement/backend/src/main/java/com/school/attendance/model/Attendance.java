package com.school.attendance.model;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity @Table(name="attendance", uniqueConstraints=@UniqueConstraint(columnNames={"student_id","attendance_date"}))
public class Attendance {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) @JoinColumn(name="student_id") private Student student;
 @Column(name="attendance_date",nullable=false) private LocalDate attendanceDate;
 @Column(nullable=false) private String status;
 private String remarks;
 public Attendance() {}
 public Attendance(Student student,LocalDate date,String status,String remarks){this.student=student;this.attendanceDate=date;this.status=status;this.remarks=remarks;}
 public Long getId(){return id;} public Student getStudent(){return student;} public void setStudent(Student v){student=v;}
 public LocalDate getAttendanceDate(){return attendanceDate;} public void setAttendanceDate(LocalDate v){attendanceDate=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;} public String getRemarks(){return remarks;} public void setRemarks(String v){remarks=v;}
}
