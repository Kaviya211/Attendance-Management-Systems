# Spring Boot backend

Requirements: JDK 17+, Maven, MySQL 8+.

1. Create database (optional; application.properties can create it automatically):
   `CREATE DATABASE school_attendance;`
2. Edit `src/main/resources/application.properties` and replace `YOUR_MYSQL_PASSWORD`.
3. In Eclipse: File > Import > Maven > Existing Maven Projects; select the `backend` folder.
4. Right-click `AttendanceApplication.java` > Run As > Java Application (or Spring Boot App).
5. API runs at `http://localhost:8080`.

Note: this is a learning/demo starter. Login currently checks credentials directly and is NOT production-secure. Before deployment, add Spring Security, BCrypt password hashing, JWT/session handling, role-based authorization, validation, and audit logging.
