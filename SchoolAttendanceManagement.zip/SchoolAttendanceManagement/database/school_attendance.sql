CREATE DATABASE IF NOT EXISTS school_attendance;
USE school_attendance;
-- Spring Data JPA creates/updates teachers, students and attendance tables on first run.
-- This file creates the database only. Keep application.properties credentials in sync.
